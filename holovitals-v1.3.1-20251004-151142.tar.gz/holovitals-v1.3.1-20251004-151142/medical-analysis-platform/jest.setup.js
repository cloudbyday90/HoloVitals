// Learn more: https://github.com/testing-library/jest-dom
// Only import jest-dom for browser environment tests
if (typeof window !== 'undefined') {
  import('@testing-library/jest-dom');
}